from mytorch.optimizer import Optimizer

"TODO: (optional) implement Momentum optimizer"
class Momentum(Optimizer):
    def __init__(self):
        pass

    def step(self):
        pass
