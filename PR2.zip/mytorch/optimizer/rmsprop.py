from mytorch.optimizer import Optimizer

"TODO: (optional) implement RMSprop optimizer"
class RMSprop(Optimizer):
    def __init__(self):
        pass

    def step(self):
        pass
