from mytorch.optimizer import Optimizer

"TODO: (optional) implement Adam optimizer"
class Adam(Optimizer):
    def __init__(self):
        pass
    
    def step(self):
        pass
